#!/bin/bash

#**********this script activates MPLS forwarding**********

. /root/message.sh

#for ping to work
ip route add 10.0.2.3/32 dev eth2 via 10.0.3.2

#set interfaces to receive mpls traffic
mpls labelspace set dev eth3 labelspace 0
mpls labelspace set dev eth2 labelspace 0


##### A2->A3, all routes

#pop incoming label 200
mpls ilm add label gen 200 labelspace 0


##### A3->A2, best and medium routes

#push label 500
var_best=`mpls nhlfe add key 0 instructions push gen 500 nexthop eth3 ipv4 10.0.5.3|grep key|cut -c 17-26`
ip route add 172.16.20.0/24 via 10.0.5.3 mpls $var_best


##### A3->A2, low route

#push label 600 for A2
#This instruction creates a new entry in the NHLFE table in order to add (push) label 600 to the packets directed to A2 and forward them to 10.0.3.2 address (nexthop) using E1's eth2 interface
var_low=`mpls nhlfe add key 0 instructions push gen 600 nexthop eth2 ipv4 10.0.3.2|grep key|cut -c 17-26`


#start working in a loop
route="best"

while [ "1" = "1" ] 
do 
   message "Currently selected route: $route"
   sleep 0.5
   # Check if E3 is still up
   status=`/usr/sbin/hping3 -c 1 --icmp 10.0.5.3 2>&1|grep "100% packet loss\|Host Unreachable"`
   case $route in
   best)
       if [ ! -z "$status" ] ;then
         #echo E3 is down
         #switch to low route
         route="low";
         ip route del 172.16.20.0/24 via 10.0.5.3 mpls $var_best
         ip route add 172.16.20.0/24 via 10.0.3.2 mpls $var_low
         #echo `date +%r` switching to low route from best.
       fi
     ;;
   low)
       if [  -z "$status" ] ;then
         #echo E3 is up again.
         #switch to best route
         route="best";
         ip route del 172.16.20.0/24 via 10.0.3.2 mpls $var_low
         ip route add 172.16.20.0/24 via 10.0.5.3 mpls $var_best
         #echo `date +%r` switching to best route from low.
       fi
   ;;
esac
	    
done
