#!/bin/bash

. /root/message.sh

#for ping to work
ip route add 10.0.4.4/32 dev eth3 via 10.0.1.5

#set interfaces to receive mpls traffic
mpls labelspace set dev eth0 labelspace 0
mpls labelspace set dev eth2 labelspace 0
mpls labelspace set dev eth3 labelspace 0


##### A2->A3, medium and low routes

#pop incoming label 10000
mpls ilm add label gen 10000 labelspace 0
#pop incoming label 100
mpls ilm add label gen 100 labelspace 0


##### A2->A3, medium route

#This instruction creates a new entry in the NHLFE table in order to add (push) label 100 to the packets directed to A3 and forward them to 10.0.2.3 address (nexthop) using E2's eth0 interface
var_medium=`mpls nhlfe add key 0 instructions push gen 100 nexthop eth0 ipv4 10.0.2.3 |grep key | cut -c 17-26`

#swap (=repush) label 100 with another label 100
mpls xc add ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var_medium


##### A2->A3, low route

#This instruction creates a new entry in the NHLFE table in order to add (push) label 200 to the packets directed to A3 and forward them to 10.0.3.1 address (nexthop) using E2's eth2 interface
var_low=`mpls nhlfe add key 0 instructions push gen 200 nexthop eth2 ipv4 10.0.3.1 |grep key | cut -c 17-26`

#swapping of label 100 with label 200 will be configured in the loop below

##### A3->A2, medium and low routes

#pop incoming label 600
mpls ilm add label gen 600 labelspace 0

#This instruction creates a new entry in the NHLFE table in order to add (push) label 20000 to the packets directed to A2 and forward them to 10.0.1.5 address (nexthop) using E2's eth3 interface
key1=`mpls nhlfe add key 0 instructions push gen 20000 nexthop eth3 ipv4 10.0.1.5| grep key |cut -c 17-26`

#This instruction puts label 600 at the bottom, placing label 20000 as outer label
key2=`mpls nhlfe add key 0 instructions push gen 600 forward $key1|grep key|cut -c 17-26`

#swap label 600 with label stack (600, 20000)
mpls xc add ilm_label gen 600 ilm_labelspace 0 nhlfe_key $key2



#work in a loop
route="medium"

while [ "1" = "1" ] 
do
 message "Currently selected route: $route"
 sleep 0.5
 #test if E3 is up
 status=`/usr/sbin/hping3 -c 1 --icmp 10.0.2.3 2>&1 | grep "100% packet loss\|Host Unreachable"`
 case $route in
   medium)
       if [ ! -z "$status" ] ;then
         #echo E3 is down.
         #switch to low route if E3 is down
         route="low";
         mpls xc del ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var_medium
         mpls xc add ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var_low
         #echo `date +%r` switching to low route from medium.
       fi
      ;;
   low)
       if [  -z "$status" ] ;then
         #echo E3 is up again.
         #switch to medium route
         route="medium";
         mpls xc del ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var_low
         mpls xc add ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var_medium
   	   #echo `date +%r` switching to medium route from low.
       fi
      ;;
esac
	    
done

