#!/bin/bash

#**********this script activates MPLS forwarding**********

. /root/message.sh

#for ping to work
ip route add 10.0.4.4/32 dev eth0 via 10.0.2.2
ip route add 10.0.3.1/32 dev eth0 via 10.0.2.2

#set interfaces to receive mpls traffic
mpls labelspace set dev eth1 labelspace 0
mpls labelspace set dev eth0 labelspace 0
mpls labelspace set dev eth2 labelspace 0


##### A2->A3, best and medium routes

#pop incoming label 100
mpls ilm add label gen 100 labelspace 0 

#This instruction creates a new entry in the NHLFE table in order to add (push) label 200 to the packets directed to A3 and forward them to 10.0.5.1 address (nexthop) using E3's eth2 interface
var=`mpls nhlfe add key 0 instructions push gen 200 nexthop eth2 ipv4 10.0.5.1 |grep key | cut -c 17-26`

#incoming label 100 is swapped with label 200
mpls xc add ilm_label gen 100 ilm_labelspace 0 nhlfe_key $var


##### A3->A2, best route

#pop incoming label 500
mpls ilm add label gen 500 labelspace 0

#This instruction creates a new entry in the NHLFE table in order to add (push) label 600 to the packets directed to A2 and forward them to 10.0.6.4 address (nexthop) using E3's eth1 interface
var_default=`mpls nhlfe add key 0 instructions push gen 600 nexthop eth1 ipv4 10.0.6.4|grep key| cut -c 17-26`

#incoming label 500 is swapped with label 600
mpls xc add ilm_label gen 500 ilm_labelspace 0 nhlfe_key $var_default


##### A3->A2, medium route

#incoming label 500 is already popped above

#This instruction creates a new entry in the NHLFE table in order to add (push) label 600 to the packets directed to hostb and forward them to 10.0.2.2 address (nexthop) using E3's eth0 interface
var_medium=`mpls nhlfe add key 0 instructions push gen 600 nexthop eth0 ipv4 10.0.2.2|grep key|cut -c 17-26`



#loop
route="best";

while [ "1" = "1" ];
do
 message "Currently selected route: $route"
 sleep 0.5
 status=`/sbin/ifconfig eth1| grep "RUNNING"`
 case $route in
 best)
   if [ -z "$status" ]; then
      route="medium";
      #if link6 is down, switch to medium route
      mpls xc del ilm_label gen 500 ilm_labelspace 0 nhlfe_key $var_default
      mpls xc add ilm_label gen 500 ilm_labelspace 0 nhlfe_key $var_medium
      #echo `date +%r` switching from best route to medium route
   fi
  ;;
 medium)
   if [ ! -z "$status" ]; then
      #if link6 comes up, switch to best route
      route="best";
      mpls xc del ilm_label gen 500 ilm_labelspace 0 nhlfe_key $var_medium
      #interface had been brought down, so we need to restore the nhlfe
      var_default=`mpls nhlfe add key 0 instructions push gen 600 nexthop eth1 ipv4 10.0.6.4|grep key| cut -c 17-26`
      mpls xc add ilm_label gen 500 ilm_labelspace 0 nhlfe_key $var_default
      #echo `date +%r` switching from medium route to best route
   fi
  ;;
esac
done
