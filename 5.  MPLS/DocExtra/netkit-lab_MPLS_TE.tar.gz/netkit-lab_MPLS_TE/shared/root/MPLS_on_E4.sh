#!/bin/bash

#**********this script activates MPLS forwarding**********

. /root/message.sh

#for ping to work
ip route add 10.0.2.3/32 dev eth0 via 10.0.4.5

#set interfaces to receive mpls traffic
mpls labelspace set dev eth0 labelspace 0
mpls labelspace set dev eth1 labelspace 0


##### A2->A3, best route

#push label 100 and send to E3

#This instruction creates a new entry in the NHLFE table in order to add (push) label 100 to the packets directed to A3 and forward them to 10.0.6.3 address (nexthop) using E4's eth1 interface
var_default=`mpls nhlfe add key 0 instructions push gen 100 nexthop eth1 ipv4 10.0.6.3 |grep key | cut -c 17-26`

#label binding: packets directed to 172.16.30.0/24 routed by 10.0.6.3 are a fec, identified by the label stored by previous instruction in $var_default.
ip route add 172.16.30.0/24 via 10.0.6.3 mpls $var_default


##### A2->A3, medium and low routes

#push label 100 and send to E5

#This instruction creates a new entry in the NHLFE table in order to add (push) label 100 to the packets directed to A3 and forward them to 10.0.4.5 address (nexthop) using E4's eth0 interface
var_indirect=`mpls nhlfe add key 0 instructions push gen 100 nexthop eth0 ipv4 10.0.4.5 |grep key | cut -c 17-26`

#label binding will be performed in the loop cycle below


##### A3->A2, all routes

#pop incoming label 600
mpls ilm add label gen 600 labelspace 0



#work in a loop
route="best"    
while [ "1" = "1" ] ;
do 
 message "Currently selected route: $route"
 sleep 0.5
 #see if Link6 is up
 status=`/usr/sbin/hping3 -c 1 --icmp 10.0.6.3 2>&1 |grep "100% packet loss\|Host Unreachable"`   
 case $route in
   best)
       if [ ! -z "$status" ] ;then  
         #if Link6 is down, switch to medium route or low route
         #from an MPLS point of view, the same configuration can be applied for both routes
         ip route del 172.16.30.0/24 via 10.0.6.3 mpls $var_default
         ip route add 172.16.30.0/24 via 10.0.4.5 mpls $var_indirect
         #echo Link6 is down, trying an alternative route through eth0
 	      status=`/usr/sbin/hping3 -c 1 --icmp  10.0.2.3 2>&1 |grep "100% packet loss\|Host Unreachable"`
         if [  -z "$status" ]; then
	         #E3 responded, so it means that just Link6 is down
            #echo E3 is still up.
            route="medium";
	         #echo `date +%r` switching to medium route from best.
	      else
	         #echo E3 appears to be down.
	         route="low";
            #echo `date +%r` switching to low route from best.
	      fi
      fi
     ;;

   medium)      
      if [  -z "$status" ] ;then
         #if link6 is up, switch to best route
         #echo Link6 is up again.
	      route="best";
	      ip route del 172.16.30.0/24 via 10.0.4.5 mpls $var_indirect
	      ip route add 172.16.30.0/24 via 10.0.6.3 mpls $var_default
	      #echo `date +%r` switching to best route from medium.
      else
         status=`/usr/sbin/hping3 -c 1 --icmp 10.0.2.3 2>&1 |grep "100% packet loss\|Host Unreachable"`
	      if [ ! -z "$status" ] ;then
	         #if E3 is down, switch to low route
	         #echo E3 appears to be down.
	         route="low";
            #echo `date +%r` switching to low route from medium.
	      fi
	   fi
      ;;

   low)
 	   if [  -z "$status" ]; then
	      #if Link6 is up, switch to best route
         #echo Link6 is up again.
	      route="best";
	      ip route del 172.16.30.0/24 via 10.0.4.5 mpls $var_indirect
	      ip route add 172.16.30.0/24 via 10.0.6.3 mpls $var_default
   	   #echo `date +%r` switching to best route from low.
      else
         status=`/usr/sbin/hping3 -c 1 --icmp 10.0.2.3 2>&1 |grep "100% packet loss\|Host Unreachable"`		 
         if [  -z "$status" ]; then
            #if just E3 is up, use medium route
            #echo E3 appears to be up again.
	         #echo `date +%r` switching to medium route from low.
	         route="medium";
	      fi
	   fi
      ;;
esac
	    
done

