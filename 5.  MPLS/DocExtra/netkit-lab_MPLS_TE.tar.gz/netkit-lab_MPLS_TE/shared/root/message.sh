function message() {
   LENGTH=$(echo $1 | wc -c)
   COLUMNS=$(tput cols)
   #save cursor position
   echo -ne "\e[s"
   #clear top line
   printf "\e[1;1H\e[40;37m%$(($COLUMNS))s\e[0m" " "
   printf "\e[2;1H%$(($COLUMNS))s" " "
   echo -e "\e[2;$(($COLUMNS/2 - $LENGTH/2))H$1"
   printf "\e[40;37m%$(($COLUMNS))s\e[0m" " "
   #restore cursor position
   echo -ne "\e[u"
}

